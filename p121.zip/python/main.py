import cv2
import numpy as np

# Load images
background = cv2.imread('background.jpeg')
foreground = cv2.imread('messi.jpg')

# Resize images
background = cv2.resize(background, (640, 480))
foreground = cv2.resize(foreground, (640, 480))

# Create mask
lower_bound = np.array([100, 100, 100])
upper_bound = np.array([255, 255, 255])
mask = cv2.inRange(foreground, lower_bound, upper_bound)
mask_inv = cv2.bitwise_not(mask)

# Create final image
background_part = cv2.bitwise_and(background, background, mask=mask)
foreground_part = cv2.bitwise_and(foreground, foreground, mask=mask_inv)
final_image = cv2.add(background_part, foreground_part)

# Display final image
cv2.imshow('Anywhere Photo Booth', final_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
